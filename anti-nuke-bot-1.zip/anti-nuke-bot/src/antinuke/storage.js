// Luu cau hinh tung server ra file JSON (data/guilds/<guildId>.json), co cache trong bo nho.
const fs = require('fs');
const path = require('path');
const { buildDefaultGuildConfig } = require('./config');

const DATA_DIR = path.join(__dirname, '..', '..', 'data', 'guilds');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const cache = new Map();

function filePath(guildId) {
  return path.join(DATA_DIR, `${guildId}.json`);
}

function mergeWithDefaults(raw) {
  const def = buildDefaultGuildConfig();
  const merged = {
    ...def,
    ...raw,
    whitelistedUsers: raw.whitelistedUsers || [],
    whitelistedRoles: raw.whitelistedRoles || [],
    whitelistedBots: raw.whitelistedBots || [],
    modules: { ...def.modules },
  };
  for (const key of Object.keys(def.modules)) {
    merged.modules[key] = { ...def.modules[key], ...((raw.modules && raw.modules[key]) || {}) };
  }
  return merged;
}

function getGuildConfig(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const fp = filePath(guildId);
  let config;
  if (fs.existsSync(fp)) {
    try {
      config = mergeWithDefaults(JSON.parse(fs.readFileSync(fp, 'utf8')));
    } catch {
      config = buildDefaultGuildConfig();
    }
  } else {
    config = buildDefaultGuildConfig();
  }
  cache.set(guildId, config);
  return config;
}

function saveGuildConfig(guildId, config) {
  cache.set(guildId, config);
  fs.writeFileSync(filePath(guildId), JSON.stringify(config, null, 2));
}

module.exports = { getGuildConfig, saveGuildConfig };
