// Diem trung tam: moi event bao ve deu goi qua day de kiem tra whitelist, dem nguong, va xu ly.
const storage = require('./storage');
const tracker = require('./tracker');
const { isWhitelisted } = require('./whitelist');
const { applyPunishment } = require('./punish');

async function handleAction(client, guild, executorId, moduleKey, meta) {
  if (!executorId || !guild) return;
  const config = storage.getGuildConfig(guild.id);
  const moduleConfig = config.modules[moduleKey];
  if (!moduleConfig || !moduleConfig.enabled) return;
  if (isWhitelisted(guild, executorId, config, client)) return;

  const entries = tracker.hit(guild.id, executorId, moduleKey, moduleConfig.windowMs, meta);
  if (entries.length >= moduleConfig.limit) {
    tracker.reset(guild.id, executorId, moduleKey);
    await applyPunishment(guild, client, executorId, moduleKey, config, entries);
  }
}

module.exports = { handleAction };
