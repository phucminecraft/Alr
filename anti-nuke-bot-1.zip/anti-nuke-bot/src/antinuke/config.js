// Dinh nghia toan bo module bao ve va gia tri mac dinh (limit / thoi gian / hinh phat).
const MODULE_DEFS = {
  massBan:              { label: 'Mass Bans',                limit: 3, windowMs: 10_000, punishment: 'ban' },
  massTimeout:          { label: 'Mass Timeouts',            limit: 5, windowMs: 15_000, punishment: 'strip' },
  massRoleAdd:          { label: 'Mass Role Adds',           limit: 5, windowMs: 10_000, punishment: 'strip' },
  massRoleRemove:       { label: 'Mass Role Removes',        limit: 5, windowMs: 10_000, punishment: 'strip' },
  massChannelCreate:    { label: 'Mass Channel Creation',    limit: 3, windowMs: 10_000, punishment: 'strip' },
  massChannelDelete:    { label: 'Mass Channel Deletion',    limit: 3, windowMs: 10_000, punishment: 'ban' },
  massChannelUpdate:    { label: 'Mass Channel Updates',     limit: 5, windowMs: 10_000, punishment: 'strip' },
  massCategoryCreate:   { label: 'Mass Category Creation',   limit: 3, windowMs: 10_000, punishment: 'strip' },
  massCategoryDelete:   { label: 'Mass Category Deletion',   limit: 3, windowMs: 10_000, punishment: 'ban' },
  massThreadCreate:     { label: 'Mass Thread Creation',     limit: 8, windowMs: 10_000, punishment: 'strip' },
  massThreadDelete:     { label: 'Mass Thread Deletion',     limit: 8, windowMs: 10_000, punishment: 'strip' },
  massRoleCreate:       { label: 'Mass Role Creation',       limit: 4, windowMs: 10_000, punishment: 'strip' },
  massRoleDelete:       { label: 'Mass Role Deletion',       limit: 3, windowMs: 10_000, punishment: 'ban' },
  massRoleUpdate:       { label: 'Mass Role Updates',        limit: 5, windowMs: 10_000, punishment: 'strip' },
  massPermissionChange: { label: 'Mass Permission Changes',  limit: 4, windowMs: 10_000, punishment: 'ban' },
  massWebhookCreate:    { label: 'Mass Webhook Creation',    limit: 4, windowMs: 10_000, punishment: 'strip' },
  massWebhookDelete:    { label: 'Mass Webhook Deletion',    limit: 4, windowMs: 10_000, punishment: 'strip' },
  massEmojiCreate:      { label: 'Mass Emoji Creation',      limit: 6, windowMs: 10_000, punishment: 'strip' },
  massEmojiDelete:      { label: 'Mass Emoji Deletion',      limit: 6, windowMs: 10_000, punishment: 'strip' },
  massStickerCreate:    { label: 'Mass Sticker Creation',    limit: 6, windowMs: 10_000, punishment: 'strip' },
  massStickerDelete:    { label: 'Mass Sticker Deletion',    limit: 6, windowMs: 10_000, punishment: 'strip' },
  massInviteCreate:     { label: 'Mass Invite Creation',     limit: 5, windowMs: 10_000, punishment: 'strip' },
  massIntegrationChange:{ label: 'Mass Integration Changes', limit: 3, windowMs: 15_000, punishment: 'ban' },
  massBotAdd:           { label: 'Mass Bot Invites',         limit: 2, windowMs: 10_000, punishment: 'ban' },
  guildSettingChange:   { label: 'Server Setting Changes',   limit: 3, windowMs: 30_000, punishment: 'strip' },
};

const DEFAULT_SNAPSHOT_INTERVAL_MS = 15 * 60_000; // 15 phut

function buildDefaultGuildConfig() {
  const modules = {};
  for (const [key, def] of Object.entries(MODULE_DEFS)) {
    modules[key] = { enabled: true, limit: def.limit, windowMs: def.windowMs, punishment: def.punishment };
  }
  return {
    logChannelId: null,
    whitelistedUsers: [],
    whitelistedRoles: [],
    whitelistedBots: [],
    snapshotIntervalMs: DEFAULT_SNAPSHOT_INTERVAL_MS,
    modules,
  };
}

module.exports = { MODULE_DEFS, buildDefaultGuildConfig, DEFAULT_SNAPSHOT_INTERVAL_MS };
