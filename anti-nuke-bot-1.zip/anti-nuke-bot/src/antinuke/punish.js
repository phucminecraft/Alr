// Xu ly khi mot nguoi vuot nguong: go quyen nguy hiem, ap dung hinh phat, canh bao, va tu khoi phuc thiet hai.
const { PermissionsBitField } = require('discord.js');
const { sendAlert } = require('./logger');
const { MODULE_DEFS } = require('./config');
const { restoreAll } = require('./backup');

// Cac module ma khi bi vuot nguong nghia la server vua bi pha hoai dien rong
// (xoa hang loat channel/category/role) -> ngoai restore-tung-entry (chinh xac,
// nhanh), chay them mot luot restoreAll doi chieu snapshot dinh ky de vet not
// nhung gi nam ngoai cua so tracker (vd ke tan cong xoa vai cai truoc khi dat
// nguong, hoac dung nhieu tai khoan/webhook khac nhau de xoa).
const FULL_RESTORE_MODULES = new Set(['massChannelDelete', 'massCategoryDelete', 'massRoleDelete']);

const DANGEROUS_PERMS = [
  PermissionsBitField.Flags.Administrator,
  PermissionsBitField.Flags.BanMembers,
  PermissionsBitField.Flags.KickMembers,
  PermissionsBitField.Flags.ManageGuild,
  PermissionsBitField.Flags.ManageRoles,
  PermissionsBitField.Flags.ManageChannels,
  PermissionsBitField.Flags.ManageWebhooks,
  PermissionsBitField.Flags.ManageGuildExpressions,
  PermissionsBitField.Flags.ManageNicknames,
  PermissionsBitField.Flags.ModerateMembers,
  PermissionsBitField.Flags.MentionEveryone,
];

// Go ngay cac role co quyen nguy hiem ma bot con du thu bac de quan ly (cach ly tuc thi).
async function defang(member) {
  try {
    const toStrip = member.roles.cache.filter(
      (r) => r.id !== member.guild.id && r.editable && DANGEROUS_PERMS.some((p) => r.permissions.has(p))
    );
    if (toStrip.size) await member.roles.remove(toStrip, 'Anti-Nuke: cach ly khan cap').catch(() => {});
  } catch {
    /* best-effort */
  }
}

// Co gang khoi phuc thiet hai da gay ra, tuong ung tung loai module.
async function mitigate(guild, moduleKey, entries) {
  try {
    if (moduleKey === 'massBan') {
      await Promise.allSettled(
        entries.map((e) =>
          e.meta?.userId ? guild.members.unban(e.meta.userId, 'Anti-Nuke: tu dong go ban').catch(() => {}) : null
        )
      );
    } else if (moduleKey === 'massChannelDelete' || moduleKey === 'massCategoryDelete') {
      for (const e of entries) {
        const m = e.meta;
        if (!m?.name) continue;
        await guild.channels
          .create({
            name: m.name,
            type: m.type,
            parent: m.parentId ?? undefined,
            topic: m.topic,
            nsfw: m.nsfw,
            bitrate: m.bitrate,
            userLimit: m.userLimit,
            rateLimitPerUser: m.rateLimitPerUser,
            permissionOverwrites: (m.permissionOverwrites || []).map((o) => ({
              id: o.id,
              type: o.type,
              allow: BigInt(o.allow),
              deny: BigInt(o.deny),
            })),
            reason: 'Anti-Nuke: tu dong khoi phuc kenh bi xoa',
          })
          .catch(() => {});
      }
    } else if (moduleKey === 'massRoleDelete') {
      for (const e of entries) {
        const m = e.meta;
        if (!m?.name) continue;
        await guild.roles
          .create({
            name: m.name,
            color: m.color,
            hoist: m.hoist,
            mentionable: m.mentionable,
            permissions: BigInt(m.permissions),
            reason: 'Anti-Nuke: tu dong khoi phuc role bi xoa',
          })
          .catch(() => {});
      }
    } else if (moduleKey === 'massRoleRemove') {
      for (const e of entries) {
        const m = e.meta;
        if (!m?.memberId || !m?.removedRoleIds?.length) continue;
        const target = await guild.members.fetch(m.memberId).catch(() => null);
        if (target) await target.roles.add(m.removedRoleIds, 'Anti-Nuke: khoi phuc role').catch(() => {});
      }
    } else if (moduleKey === 'massRoleAdd') {
      for (const e of entries) {
        const m = e.meta;
        if (!m?.memberId || !m?.addedRoleIds?.length) continue;
        const target = await guild.members.fetch(m.memberId).catch(() => null);
        if (target) await target.roles.remove(m.addedRoleIds, 'Anti-Nuke: go role duoc cap trai phep').catch(() => {});
      }
    }
  } catch {
    /* best-effort, khong lam gian doan flow chinh */
  }

  // Lop khoi phuc toan dien: chi chay them cho cac module pha huy dien rong,
  // va chi khi co snapshot (loadSnapshot ben trong restoreAll tra rong neu chua co).
  if (FULL_RESTORE_MODULES.has(moduleKey)) {
    try {
      await restoreAll(guild);
    } catch {
      /* best-effort */
    }
  }
}

async function applyPunishment(guild, client, executorId, moduleKey, guildConfig, entries) {
  const moduleConfig = guildConfig.modules[moduleKey];
  const label = MODULE_DEFS[moduleKey]?.label || moduleKey;
  const member = await guild.members.fetch(executorId).catch(() => null);
  if (!member || member.id === guild.ownerId || member.id === client.user.id) return;

  const reason = `Anti-Nuke: vuot nguong ${label} (${entries.length} hanh dong)`;
  await defang(member);

  let actionTaken = 'strip (go role nguy hiem)';
  try {
    if (moduleConfig.punishment === 'ban') {
      await guild.members.ban(member.id, { reason });
      actionTaken = 'ban';
    } else if (moduleConfig.punishment === 'kick') {
      await member.kick(reason);
      actionTaken = 'kick';
    } else if (moduleConfig.punishment === 'timeout') {
      await member.timeout(28 * 24 * 60 * 60 * 1000, reason);
      actionTaken = 'timeout 28 ngay';
    }
  } catch (err) {
    actionTaken += ` (khong ap dung duoc hinh phat chinh: ${err.message})`;
  }

  await sendAlert(guild, guildConfig, {
    title: `Anti-Nuke: ${label}`,
    description: `<@${executorId}> (\`${executorId}\`) da vuot nguong **${moduleConfig.limit}** hanh dong trong **${(
      moduleConfig.windowMs / 1000
    ).toFixed(0)}s**.`,
    fields: [
      { name: 'Hanh dong xu ly', value: actionTaken, inline: true },
      { name: 'So lan phat hien', value: `${entries.length}`, inline: true },
    ],
  });

  await mitigate(guild, moduleKey, entries);
}

module.exports = { applyPunishment, defang };
