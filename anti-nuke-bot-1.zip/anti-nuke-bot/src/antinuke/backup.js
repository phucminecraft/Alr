// Chup nhanh (snapshot) toan bo cau truc server theo dinh ky, va khoi phuc toan dien
// khi server bi nuke nang (mass xoa channel/category/role vuot xa nhung gi tracker
// con giu duoc). Day la lop phong ve thu 2, bo sung cho co che restore-tung-entry
// da co san trong punish.js (co che do nhanh va chinh xac hon vi dung dung du lieu
// cua vat vua bi xoa, nhung chi phu duoc dung nhung entry nam trong cua so tracker).
const fs = require('fs');
const path = require('path');
const { ChannelType } = require('discord.js');

const SNAPSHOT_DIR = path.join(__dirname, '..', '..', 'data', 'guilds');
if (!fs.existsSync(SNAPSHOT_DIR)) fs.mkdirSync(SNAPSHOT_DIR, { recursive: true });

function snapshotFilePath(guildId) {
  return path.join(SNAPSHOT_DIR, `${guildId}.snapshot.json`);
}

// Lay toan bo role (tru @everyone) va channel/category hien tai cua guild,
// du lieu vua du de tao lai neu bi xoa: ten, loai, quyen, vi tri, overwrite.
function snapshotGuild(guild) {
  const roles = guild.roles.cache
    .filter((r) => r.id !== guild.id) // bo qua @everyone, khong the tao lai role nay
    .map((r) => ({
      name: r.name,
      color: r.color,
      hoist: r.hoist,
      mentionable: r.mentionable,
      permissions: r.permissions.bitfield.toString(),
      position: r.position,
    }))
    .sort((a, b) => b.position - a.position);

  const channels = guild.channels.cache
    .map((c) => ({
      name: c.name,
      type: c.type,
      // Luu ten category thay vi id: id se doi neu category bi xoa roi tao lai.
      parentName: c.parent?.name ?? null,
      position: c.rawPosition ?? c.position ?? 0,
      topic: c.topic ?? undefined,
      nsfw: c.nsfw ?? undefined,
      bitrate: c.bitrate ?? undefined,
      userLimit: c.userLimit ?? undefined,
      rateLimitPerUser: c.rateLimitPerUser ?? undefined,
      permissionOverwrites: (c.permissionOverwrites?.cache?.map((o) => ({
        // Luu ten role/id user thay vi id role tho, vi role co the duoc tao lai voi id moi.
        roleName: guild.roles.cache.get(o.id)?.name ?? null,
        rawId: o.id,
        type: o.type,
        allow: o.allow.bitfield.toString(),
        deny: o.deny.bitfield.toString(),
      })) ?? []),
    }))
    // Category truoc, roi den channel thuong -> tao lai dung thu tu cha/con.
    .sort((a, b) => (a.type === ChannelType.GuildCategory ? -1 : 1) - (b.type === ChannelType.GuildCategory ? -1 : 1));

  return { takenAt: Date.now(), roles, channels };
}

function saveSnapshot(guildId, snapshot) {
  fs.writeFileSync(snapshotFilePath(guildId), JSON.stringify(snapshot, null, 2));
}

function loadSnapshot(guildId) {
  const fp = snapshotFilePath(guildId);
  if (!fs.existsSync(fp)) return null;
  try {
    return JSON.parse(fs.readFileSync(fp, 'utf8'));
  } catch {
    return null;
  }
}

function takeAndSaveSnapshot(guild) {
  const snap = snapshotGuild(guild);
  saveSnapshot(guild.id, snap);
  return snap;
}

// Doi id role trong overwrite snapshot sang id hien tai, dua theo ten role
// (id cu chac chan sai neu role vua duoc tao lai boi restoreAll).
function resolveOverwriteId(guild, ow) {
  if (ow.type === 1) return ow.rawId; // type 1 = member, id nguoi dung khong doi
  if (ow.roleName) {
    const role = guild.roles.cache.find((r) => r.name === ow.roleName);
    if (role) return role.id;
    if (ow.roleName === '@everyone') return guild.id;
  }
  return guild.roles.cache.has(ow.rawId) ? ow.rawId : null;
}

// Khoi phuc toan dien: doi chieu snapshot gan nhat voi trang thai hien tai,
// tao lai MOI role/channel co trong snapshot nhung dang thieu (khop theo ten,
// khong tao trung neu ten da ton tai). Best-effort tuyet doi - Discord khong
// giu lai id cu, thu tu chinh xac tuyet doi, hay lich su tin nhan da mat.
async function restoreAll(guild, { reason = 'Anti-Nuke: khoi phuc toan dien sau nuke' } = {}) {
  const snapshot = loadSnapshot(guild.id);
  const result = { rolesCreated: 0, categoriesCreated: 0, channelsCreated: 0, errors: 0 };
  if (!snapshot) return result;

  // 1) Role truoc (channel co the can overwrite tro toi role vua tao lai).
  const rolesSortedHighFirst = [...snapshot.roles].sort((a, b) => b.position - a.position);
  for (const r of rolesSortedHighFirst) {
    if (guild.roles.cache.some((existing) => existing.name === r.name)) continue;
    try {
      await guild.roles.create({
        name: r.name,
        color: r.color,
        hoist: r.hoist,
        mentionable: r.mentionable,
        permissions: BigInt(r.permissions),
        reason,
      });
      result.rolesCreated += 1;
    } catch {
      result.errors += 1;
    }
  }

  // 2) Category truoc (channel thuong can parent da ton tai).
  const categories = snapshot.channels.filter((c) => c.type === ChannelType.GuildCategory);
  for (const c of categories) {
    if (guild.channels.cache.some((existing) => existing.name === c.name && existing.type === ChannelType.GuildCategory)) continue;
    try {
      const created = await guild.channels.create({
        name: c.name,
        type: ChannelType.GuildCategory,
        reason,
      });
      await applyOverwrites(guild, created, c.permissionOverwrites);
      result.categoriesCreated += 1;
    } catch {
      result.errors += 1;
    }
  }

  // 3) Channel thuong, gan lai parent theo ten category.
  const others = snapshot.channels.filter((c) => c.type !== ChannelType.GuildCategory);
  for (const c of others) {
    if (guild.channels.cache.some((existing) => existing.name === c.name && existing.type === c.type)) continue;
    const parent = c.parentName ? guild.channels.cache.find((ch) => ch.name === c.parentName && ch.type === ChannelType.GuildCategory) : null;
    try {
      const created = await guild.channels.create({
        name: c.name,
        type: c.type,
        parent: parent?.id,
        topic: c.topic,
        nsfw: c.nsfw,
        bitrate: c.bitrate,
        userLimit: c.userLimit,
        rateLimitPerUser: c.rateLimitPerUser,
        reason,
      });
      await applyOverwrites(guild, created, c.permissionOverwrites);
      result.channelsCreated += 1;
    } catch {
      result.errors += 1;
    }
  }

  return result;
}

async function applyOverwrites(guild, channel, overwrites) {
  if (!overwrites?.length) return;
  const resolved = overwrites
    .map((o) => ({ id: resolveOverwriteId(guild, o), type: o.type, allow: BigInt(o.allow), deny: BigInt(o.deny) }))
    .filter((o) => o.id);
  if (resolved.length) await channel.permissionOverwrites.set(resolved, 'Anti-Nuke: khoi phuc permission overwrite').catch(() => {});
}

// Chay snapshot dinh ky cho tat ca guild bot dang o, khoang cach lay tu config tung server.
function startAutoSnapshot(client, storage) {
  const timers = new Map();

  function scheduleFor(guild) {
    if (timers.has(guild.id)) clearInterval(timers.get(guild.id));
    const config = storage.getGuildConfig(guild.id);
    const intervalMs = Math.max(config.snapshotIntervalMs || 15 * 60_000, 60_000); // toi thieu 1 phut, tranh spam API
    const timer = setInterval(() => {
      takeAndSaveSnapshot(guild).catch?.(() => {});
    }, intervalMs);
    timer.unref?.();
    timers.set(guild.id, timer);
  }

  client.guilds.cache.forEach((g) => {
    takeAndSaveSnapshot(g); // snapshot ngay khi bot khoi dong, tranh cua so trong lich su
    scheduleFor(g);
  });
  client.on('guildCreate', (g) => {
    takeAndSaveSnapshot(g);
    scheduleFor(g);
  });
  client.on('guildDelete', (g) => {
    if (timers.has(g.id)) clearInterval(timers.get(g.id));
    timers.delete(g.id);
  });

  return timers;
}

module.exports = { snapshotGuild, saveSnapshot, loadSnapshot, takeAndSaveSnapshot, restoreAll, startAutoSnapshot };
