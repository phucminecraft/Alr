// Kiem tra mien tru: chu server, bot, user/role/bot duoc cau hinh whitelist.
function isWhitelisted(guild, executorId, config, client) {
  if (!executorId) return true;
  if (client?.user && executorId === client.user.id) return true;
  if (executorId === guild.ownerId) return true;
  if (config.whitelistedUsers.includes(executorId)) return true;
  if (config.whitelistedBots.includes(executorId)) return true;
  const member = guild.members.cache.get(executorId);
  if (member && config.whitelistedRoles.some((id) => member.roles.cache.has(id))) return true;
  return false;
}

module.exports = { isWhitelisted };
