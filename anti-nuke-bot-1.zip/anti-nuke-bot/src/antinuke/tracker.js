// Dem hanh dong theo cua so thoi gian truot (sliding window) cho tung (guild, nguoi thuc hien, module).
class ActionTracker {
  constructor() {
    this.data = new Map(); // guildId -> Map(executorId -> Map(moduleKey -> [{ts, meta}]))
  }

  _bucket(guildId, executorId, moduleKey) {
    if (!this.data.has(guildId)) this.data.set(guildId, new Map());
    const g = this.data.get(guildId);
    if (!g.has(executorId)) g.set(executorId, new Map());
    const u = g.get(executorId);
    if (!u.has(moduleKey)) u.set(moduleKey, []);
    return u.get(moduleKey);
  }

  // Ghi nhan 1 hanh dong, tra ve danh sach hanh dong con trong cua so thoi gian.
  hit(guildId, executorId, moduleKey, windowMs, meta = null) {
    const arr = this._bucket(guildId, executorId, moduleKey);
    const now = Date.now();
    arr.push({ ts: now, meta });
    const cutoff = now - windowMs;
    while (arr.length && arr[0].ts < cutoff) arr.shift();
    return arr;
  }

  reset(guildId, executorId, moduleKey) {
    const g = this.data.get(guildId);
    if (!g) return;
    const u = g.get(executorId);
    if (!u) return;
    u.set(moduleKey, []);
  }
}

module.exports = new ActionTracker();
