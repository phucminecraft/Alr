// Lap rap toan bo module Anti-Nuke vao mot Discord client co san.
const engine = require('./engine');
const storage = require('./storage');
const { startAutoSnapshot } = require('./backup');
const channelsEvt = require('./events/channels');
const threadsEvt = require('./events/threads');
const rolesEvt = require('./events/roles');
const membersEvt = require('./events/members');
const webhooksEvt = require('./events/webhooks');
const emojiStickerEvt = require('./events/emojisStickers');
const invitesEvt = require('./events/invites');
const guildEvt = require('./events/guild');
const antinukeCommand = require('./commands/antinuke');

function setupAntiNuke(client) {
  // Snapshot dinh ky can guild cache day du -> cho toi khi client san sang.
  client.once('ready', () => startAutoSnapshot(client, storage));

  channelsEvt.register(client);
  threadsEvt.register(client);
  rolesEvt.register(client);
  membersEvt.register(client);
  webhooksEvt.register(client);
  emojiStickerEvt.register(client);
  invitesEvt.register(client);
  guildEvt.register(client);

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand() || interaction.commandName !== 'antinuke') return;
    try {
      await antinukeCommand.execute(interaction);
    } catch (err) {
      console.error(err);
      const payload = { content: 'Da xay ra loi khi xu ly lenh.', ephemeral: true };
      if (interaction.deferred || interaction.replied) interaction.editReply(payload).catch(() => {});
      else interaction.reply(payload).catch(() => {});
    }
  });
}

module.exports = { setupAntiNuke, handleAction: engine.handleAction, antinukeCommandData: antinukeCommand.data };
