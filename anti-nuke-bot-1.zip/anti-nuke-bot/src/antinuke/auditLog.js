// Tra cuu audit log de tim ra ai la nguoi thuc hien mot hanh dong (Discord khong luon gui san executor).
const { AuditLogEvent } = require('discord.js');

async function fetchLatestExecutor(guild, type, { targetId = null, withinMs = 5000, limit = 5 } = {}) {
  try {
    // Audit log can vai tram ms de duoc ghi nhan sau khi hanh dong xay ra.
    await new Promise((r) => setTimeout(r, 300));
    const logs = await guild.fetchAuditLogs({ type, limit });
    const cutoff = Date.now() - withinMs;
    const entry =
      logs.entries.find(
        (e) => e.createdTimestamp >= cutoff && (!targetId || e.targetId === targetId)
      ) || (!targetId ? logs.entries.first() : null);
    if (!entry) return null;
    const executorId = entry.executorId || entry.executor?.id;
    if (!executorId) return null;
    return { executorId, entry };
  } catch {
    return null;
  }
}

module.exports = { fetchLatestExecutor, AuditLogEvent };
