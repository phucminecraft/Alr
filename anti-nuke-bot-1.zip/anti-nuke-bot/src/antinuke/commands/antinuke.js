const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');
const { MODULE_DEFS } = require('../config');
const storage = require('../storage');
const { takeAndSaveSnapshot, restoreAll, loadSnapshot } = require('../backup');

const moduleChoices = Object.entries(MODULE_DEFS).map(([value, def]) => ({ name: def.label, value }));

const data = new SlashCommandBuilder()
  .setName('antinuke')
  .setDescription('Cau hinh he thong Anti-Nuke')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand((sc) => sc.setName('status').setDescription('Xem trang thai cau hinh Anti-Nuke hien tai'))
  .addSubcommand((sc) =>
    sc
      .setName('setup')
      .setDescription('Dat kenh nhan canh bao')
      .addChannelOption((o) =>
        o.setName('channel').setDescription('Kenh nhan canh bao').addChannelTypes(ChannelType.GuildText).setRequired(true)
      )
  )
  .addSubcommand((sc) =>
    sc
      .setName('toggle')
      .setDescription('Bat/tat mot module bao ve')
      .addStringOption((o) => o.setName('module').setDescription('Module').setRequired(true).addChoices(...moduleChoices))
      .addBooleanOption((o) => o.setName('state').setDescription('true = bat, false = tat').setRequired(true))
  )
  .addSubcommand((sc) =>
    sc
      .setName('config')
      .setDescription('Chinh nguong, thoi gian va hinh phat cho mot module')
      .addStringOption((o) => o.setName('module').setDescription('Module').setRequired(true).addChoices(...moduleChoices))
      .addIntegerOption((o) => o.setName('limit').setDescription('So hanh dong toi da').setRequired(true).setMinValue(1).setMaxValue(50))
      .addIntegerOption((o) => o.setName('amount').setDescription('Gia tri thoi gian').setRequired(true).setMinValue(1).setMaxValue(1000))
      .addStringOption((o) =>
        o
          .setName('unit')
          .setDescription('Don vi thoi gian')
          .setRequired(true)
          .addChoices({ name: 'Giay', value: 'seconds' }, { name: 'Phut', value: 'minutes' }, { name: 'Gio', value: 'hours' })
      )
      .addStringOption((o) =>
        o
          .setName('punishment')
          .setDescription('Hinh phat ap dung')
          .setRequired(true)
          .addChoices(
            { name: 'Ban (cam vinh vien)', value: 'ban' },
            { name: 'Kick (duoi khoi server)', value: 'kick' },
            { name: 'Timeout (28 ngay)', value: 'timeout' },
            { name: 'Strip (chi go role nguy hiem)', value: 'strip' }
          )
      )
  )
  .addSubcommand((sc) =>
    sc
      .setName('restore')
      .setDescription('Khoi phuc toan dien channel/role tu snapshot gan nhat (dung khi server bi nuke nang)')
      .addBooleanOption((o) =>
        o.setName('confirm').setDescription('Xac nhan thuc hien khoi phuc (bat buoc = true)').setRequired(true)
      )
  )
  .addSubcommandGroup((g) =>
    g
      .setName('backup')
      .setDescription('Quan ly snapshot dung de khoi phuc toan dien')
      .addSubcommand((sc) => sc.setName('now').setDescription('Chup snapshot ngay bay gio'))
      .addSubcommand((sc) => sc.setName('status').setDescription('Xem thoi diem snapshot gan nhat'))
      .addSubcommand((sc) =>
        sc
          .setName('interval')
          .setDescription('Dat khoang cach tu dong chup snapshot')
          .addIntegerOption((o) => o.setName('amount').setDescription('Gia tri thoi gian').setRequired(true).setMinValue(1).setMaxValue(1440))
          .addStringOption((o) =>
            o
              .setName('unit')
              .setDescription('Don vi thoi gian')
              .setRequired(true)
              .addChoices({ name: 'Phut', value: 'minutes' }, { name: 'Gio', value: 'hours' })
          )
      )
  )
  .addSubcommandGroup((g) =>
    g
      .setName('whitelist')
      .setDescription('Quan ly danh sach mien tru')
      .addSubcommand((sc) =>
        sc.setName('add-user').setDescription('Them nguoi dung vao whitelist').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true))
      )
      .addSubcommand((sc) =>
        sc.setName('remove-user').setDescription('Xoa nguoi dung khoi whitelist').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true))
      )
      .addSubcommand((sc) =>
        sc.setName('add-role').setDescription('Them role vao whitelist').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
      )
      .addSubcommand((sc) =>
        sc.setName('remove-role').setDescription('Xoa role khoi whitelist').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
      )
      .addSubcommand((sc) =>
        sc.setName('add-bot').setDescription('Them bot tin cay vao whitelist').addUserOption((o) => o.setName('bot').setDescription('Bot').setRequired(true))
      )
      .addSubcommand((sc) =>
        sc.setName('remove-bot').setDescription('Xoa bot khoi whitelist').addUserOption((o) => o.setName('bot').setDescription('Bot').setRequired(true))
      )
  );

function unitToMs(amount, unit) {
  const mult = unit === 'seconds' ? 1000 : unit === 'minutes' ? 60_000 : 3_600_000;
  return amount * mult;
}

async function execute(interaction) {
  const guildId = interaction.guild.id;
  const config = storage.getGuildConfig(guildId);
  const group = interaction.options.getSubcommandGroup(false);
  const sub = interaction.options.getSubcommand();

  if (group === 'backup') {
    if (sub === 'now') {
      const snap = takeAndSaveSnapshot(interaction.guild);
      return interaction.reply({
        content: `Da chup snapshot: ${snap.roles.length} role, ${snap.channels.length} channel/category.`,
        ephemeral: true,
      });
    }
    if (sub === 'status') {
      const snap = loadSnapshot(guildId);
      const desc = snap
        ? `Snapshot gan nhat: <t:${Math.floor(snap.takenAt / 1000)}:R>, ${snap.roles.length} role, ${snap.channels.length} channel/category.`
        : 'Chua co snapshot nao. Dung `/antinuke backup now` de tao ngay.';
      return interaction.reply({ content: desc, ephemeral: true });
    }
    if (sub === 'interval') {
      const amount = interaction.options.getInteger('amount');
      const unit = interaction.options.getString('unit');
      config.snapshotIntervalMs = amount * (unit === 'hours' ? 3_600_000 : 60_000);
      storage.saveGuildConfig(guildId, config);
      return interaction.reply({
        content: `Se tu dong chup snapshot moi ${amount} ${unit === 'hours' ? 'gio' : 'phut'} (co hieu luc tu lan khoi dong bot tiep theo).`,
        ephemeral: true,
      });
    }
  }

  if (sub === 'restore') {
    const confirm = interaction.options.getBoolean('confirm');
    if (!confirm) return interaction.reply({ content: 'Huy: can dat `confirm: true` de thuc hien khoi phuc.', ephemeral: true });
    const snap = loadSnapshot(guildId);
    if (!snap) return interaction.reply({ content: 'Chua co snapshot nao de khoi phuc tu do. Dung `/antinuke backup now` truoc.', ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    const result = await restoreAll(interaction.guild);
    return interaction.editReply(
      `Da khoi phuc: ${result.rolesCreated} role, ${result.categoriesCreated} category, ${result.channelsCreated} channel` +
        (result.errors ? ` (${result.errors} muc loi, xem log console).` : '.')
    );
  }

  if (group === 'whitelist') {
    if (sub === 'add-user') {
      const u = interaction.options.getUser('user');
      if (!config.whitelistedUsers.includes(u.id)) config.whitelistedUsers.push(u.id);
    } else if (sub === 'remove-user') {
      const u = interaction.options.getUser('user');
      config.whitelistedUsers = config.whitelistedUsers.filter((id) => id !== u.id);
    } else if (sub === 'add-role') {
      const r = interaction.options.getRole('role');
      if (!config.whitelistedRoles.includes(r.id)) config.whitelistedRoles.push(r.id);
    } else if (sub === 'remove-role') {
      const r = interaction.options.getRole('role');
      config.whitelistedRoles = config.whitelistedRoles.filter((id) => id !== r.id);
    } else if (sub === 'add-bot') {
      const b = interaction.options.getUser('bot');
      if (!config.whitelistedBots.includes(b.id)) config.whitelistedBots.push(b.id);
    } else if (sub === 'remove-bot') {
      const b = interaction.options.getUser('bot');
      config.whitelistedBots = config.whitelistedBots.filter((id) => id !== b.id);
    }
    storage.saveGuildConfig(guildId, config);
    return interaction.reply({ content: 'Da cap nhat whitelist.', ephemeral: true });
  }

  if (sub === 'setup') {
    const channel = interaction.options.getChannel('channel');
    config.logChannelId = channel.id;
    storage.saveGuildConfig(guildId, config);
    return interaction.reply({ content: `Kenh log Anti-Nuke: <#${channel.id}>`, ephemeral: true });
  }

  if (sub === 'toggle') {
    const moduleKey = interaction.options.getString('module');
    const state = interaction.options.getBoolean('state');
    config.modules[moduleKey].enabled = state;
    storage.saveGuildConfig(guildId, config);
    return interaction.reply({ content: `${MODULE_DEFS[moduleKey].label}: ${state ? 'BAT' : 'TAT'}`, ephemeral: true });
  }

  if (sub === 'config') {
    const moduleKey = interaction.options.getString('module');
    const limit = interaction.options.getInteger('limit');
    const amount = interaction.options.getInteger('amount');
    const unit = interaction.options.getString('unit');
    const punishment = interaction.options.getString('punishment');
    const windowMs = unitToMs(amount, unit);
    config.modules[moduleKey] = { ...config.modules[moduleKey], limit, windowMs, punishment };
    storage.saveGuildConfig(guildId, config);
    const unitLabel = unit === 'seconds' ? 'giay' : unit === 'minutes' ? 'phut' : 'gio';
    return interaction.reply({
      content: `${MODULE_DEFS[moduleKey].label} -> nguong ${limit} hanh dong / ${amount} ${unitLabel}, hinh phat: ${punishment}.`,
      ephemeral: true,
    });
  }

  if (sub === 'status') {
    const embed = new EmbedBuilder()
      .setTitle('Trang thai Anti-Nuke')
      .setColor(0x57f287)
      .setDescription(
        `Kenh log: ${config.logChannelId ? `<#${config.logChannelId}>` : 'Chua dat'}\n` +
          `Whitelist: ${config.whitelistedUsers.length} nguoi dung, ${config.whitelistedRoles.length} role, ${config.whitelistedBots.length} bot`
      );
    const lines = Object.entries(config.modules).map(([key, m]) => {
      const label = MODULE_DEFS[key].label;
      const sec = (m.windowMs / 1000).toFixed(0);
      return `${m.enabled ? '[BAT]' : '[TAT]'} ${label} - ${m.limit} lan / ${sec}s - ${m.punishment}`;
    });
    for (let i = 0; i < lines.length; i += 8) {
      embed.addFields({ name: i === 0 ? 'Module' : '\u200b', value: lines.slice(i, i + 8).join('\n') });
    }
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
}

module.exports = { data, execute };
