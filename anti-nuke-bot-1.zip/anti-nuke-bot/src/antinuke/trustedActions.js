// Khi mod dung lenh /ban, /kick, /timeout cua chinh bot nay, Discord van ban ra
// event guildBanAdd / guildMemberUpdate binh thuong -> antinuke se tra audit log,
// thay executor la vi mod do, va co the dem vao nguong Mass Ban / Mass Timeout.
// Neu mod dang don dep raid (vd ban lien tuc 5 acc rac trong vai giay), ho se bi
// chinh anti-nuke tuoc quyen/ban oan. Module nay danh dau truoc "hanh dong nay la
// hop phap, toi biet roi" de event handler bo qua buoc dem nguong cho dung hanh dong do.
const TTL_MS = 8000; // du thoi gian de audit log kip xuat hien va event handler doc duoc co
const pending = new Map(); // key -> expiresAt

function key(guildId, targetId, kind) {
  return `${guildId}:${targetId}:${kind}`;
}

function markTrusted(guildId, targetId, kind) {
  const k = key(guildId, targetId, kind);
  pending.set(k, Date.now() + TTL_MS);
  setTimeout(() => pending.delete(k), TTL_MS + 1000).unref?.();
}

// Kiem tra va TIEU THU luon (dung 1 lan): tranh truong hop mod ban that cung
// target ngay sau do lai duoc mien tru theo dau vet cu.
function consumeTrusted(guildId, targetId, kind) {
  const k = key(guildId, targetId, kind);
  const expiresAt = pending.get(k);
  if (!expiresAt) return false;
  pending.delete(k);
  return expiresAt > Date.now();
}

module.exports = { markTrusted, consumeTrusted };
