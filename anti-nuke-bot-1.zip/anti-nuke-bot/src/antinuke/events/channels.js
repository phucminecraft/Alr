const { ChannelType, AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

function snapshotChannel(channel) {
  return {
    name: channel.name,
    type: channel.type,
    parentId: channel.parentId,
    topic: channel.topic ?? undefined,
    nsfw: channel.nsfw ?? undefined,
    bitrate: channel.bitrate ?? undefined,
    userLimit: channel.userLimit ?? undefined,
    rateLimitPerUser: channel.rateLimitPerUser ?? undefined,
    permissionOverwrites:
      channel.permissionOverwrites?.cache?.map((o) => ({
        id: o.id,
        type: o.type,
        allow: o.allow.bitfield.toString(),
        deny: o.deny.bitfield.toString(),
      })) ?? [],
  };
}

function moduleForChannel(channel, createOrDelete) {
  const isCategory = channel.type === ChannelType.GuildCategory;
  if (createOrDelete === 'create') return isCategory ? 'massCategoryCreate' : 'massChannelCreate';
  return isCategory ? 'massCategoryDelete' : 'massChannelDelete';
}

function register(client) {
  client.on('channelCreate', async (channel) => {
    if (!channel.guild) return;
    const result = await fetchLatestExecutor(channel.guild, AuditLogEvent.ChannelCreate, { targetId: channel.id });
    if (!result) return;
    await handleAction(client, channel.guild, result.executorId, moduleForChannel(channel, 'create'), {
      channelId: channel.id,
      name: channel.name,
    });
  });

  client.on('channelDelete', async (channel) => {
    if (!channel.guild) return;
    const result = await fetchLatestExecutor(channel.guild, AuditLogEvent.ChannelDelete, { targetId: channel.id });
    if (!result) return;
    await handleAction(client, channel.guild, result.executorId, moduleForChannel(channel, 'delete'), snapshotChannel(channel));
  });

  client.on('channelUpdate', async (oldChannel, newChannel) => {
    if (!newChannel.guild) return;
    const oldOv = oldChannel.permissionOverwrites?.cache;
    const newOv = newChannel.permissionOverwrites?.cache;
    const overwritesChanged =
      !oldOv || !newOv || oldOv.size !== newOv.size ||
      [...newOv.values()].some((o) => {
        const prev = oldOv.get(o.id);
        return !prev || prev.allow.bitfield !== o.allow.bitfield || prev.deny.bitfield !== o.deny.bitfield;
      });

    if (overwritesChanged) {
      const result = await fetchLatestExecutor(newChannel.guild, AuditLogEvent.ChannelOverwriteUpdate, {
        targetId: newChannel.id,
      });
      if (result) await handleAction(client, newChannel.guild, result.executorId, 'massPermissionChange', { channelId: newChannel.id });
      return;
    }

    const propsChanged =
      oldChannel.name !== newChannel.name ||
      oldChannel.topic !== newChannel.topic ||
      oldChannel.nsfw !== newChannel.nsfw ||
      oldChannel.parentId !== newChannel.parentId ||
      oldChannel.bitrate !== newChannel.bitrate ||
      oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser;
    if (!propsChanged) return;

    const result = await fetchLatestExecutor(newChannel.guild, AuditLogEvent.ChannelUpdate, { targetId: newChannel.id });
    if (!result) return;
    await handleAction(client, newChannel.guild, result.executorId, 'massChannelUpdate', { channelId: newChannel.id });
  });
}

module.exports = { register, snapshotChannel };
