const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

function register(client) {
  client.on('webhooksUpdate', async (channel) => {
    const guild = channel.guild;
    const [createResult, deleteResult] = await Promise.all([
      fetchLatestExecutor(guild, AuditLogEvent.WebhookCreate, { withinMs: 4000 }),
      fetchLatestExecutor(guild, AuditLogEvent.WebhookDelete, { withinMs: 4000 }),
    ]);
    const pick = [createResult, deleteResult]
      .filter(Boolean)
      .sort((a, b) => b.entry.createdTimestamp - a.entry.createdTimestamp)[0];
    if (!pick) return;
    const moduleKey = pick.entry.action === AuditLogEvent.WebhookCreate ? 'massWebhookCreate' : 'massWebhookDelete';
    await handleAction(client, guild, pick.executorId, moduleKey, { channelId: channel.id });
  });
}

module.exports = { register };
