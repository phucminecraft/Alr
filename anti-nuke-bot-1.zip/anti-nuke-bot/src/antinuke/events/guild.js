const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

const WATCHED_FIELDS = [
  'name', 'iconURL', 'afkChannelId', 'afkTimeout', 'systemChannelId', 'verificationLevel',
  'explicitContentFilter', 'defaultMessageNotifications', 'mfaLevel', 'premiumProgressBarEnabled',
  'rulesChannelId', 'publicUpdatesChannelId', 'preferredLocale', 'ownerId',
];

function register(client) {
  client.on('guildUpdate', async (oldGuild, newGuild) => {
    const changed = WATCHED_FIELDS.some((f) => {
      const a = typeof oldGuild[f] === 'function' ? oldGuild[f]() : oldGuild[f];
      const b = typeof newGuild[f] === 'function' ? newGuild[f]() : newGuild[f];
      return a !== b;
    });
    if (!changed) return;
    const result = await fetchLatestExecutor(newGuild, AuditLogEvent.GuildUpdate);
    if (result) await handleAction(client, newGuild, result.executorId, 'guildSettingChange', {});
  });

  client.on('guildIntegrationsUpdate', async (guild) => {
    const types = [AuditLogEvent.IntegrationCreate, AuditLogEvent.IntegrationUpdate, AuditLogEvent.IntegrationDelete];
    const results = await Promise.all(types.map((t) => fetchLatestExecutor(guild, t, { withinMs: 4000 })));
    const pick = results.filter(Boolean).sort((a, b) => b.entry.createdTimestamp - a.entry.createdTimestamp)[0];
    if (pick) await handleAction(client, guild, pick.executorId, 'massIntegrationChange', {});
  });
}

module.exports = { register };
