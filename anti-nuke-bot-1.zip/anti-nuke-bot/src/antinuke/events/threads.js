const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

function register(client) {
  client.on('threadCreate', async (thread) => {
    const result = await fetchLatestExecutor(thread.guild, AuditLogEvent.ThreadCreate, { targetId: thread.id });
    if (result) await handleAction(client, thread.guild, result.executorId, 'massThreadCreate', { threadId: thread.id });
  });

  client.on('threadDelete', async (thread) => {
    const result = await fetchLatestExecutor(thread.guild, AuditLogEvent.ThreadDelete, { targetId: thread.id });
    if (result) await handleAction(client, thread.guild, result.executorId, 'massThreadDelete', { threadId: thread.id });
  });
}

module.exports = { register };
