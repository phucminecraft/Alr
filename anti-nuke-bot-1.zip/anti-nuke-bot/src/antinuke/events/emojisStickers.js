const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

function register(client) {
  client.on('emojiCreate', async (emoji) => {
    const result = await fetchLatestExecutor(emoji.guild, AuditLogEvent.EmojiCreate, { targetId: emoji.id });
    if (result) await handleAction(client, emoji.guild, result.executorId, 'massEmojiCreate', { emojiId: emoji.id });
  });

  client.on('emojiDelete', async (emoji) => {
    const result = await fetchLatestExecutor(emoji.guild, AuditLogEvent.EmojiDelete, { targetId: emoji.id });
    if (result) await handleAction(client, emoji.guild, result.executorId, 'massEmojiDelete', { name: emoji.name });
  });

  client.on('stickerCreate', async (sticker) => {
    const result = await fetchLatestExecutor(sticker.guild, AuditLogEvent.StickerCreate, { targetId: sticker.id });
    if (result) await handleAction(client, sticker.guild, result.executorId, 'massStickerCreate', { stickerId: sticker.id });
  });

  client.on('stickerDelete', async (sticker) => {
    const result = await fetchLatestExecutor(sticker.guild, AuditLogEvent.StickerDelete, { targetId: sticker.id });
    if (result) await handleAction(client, sticker.guild, result.executorId, 'massStickerDelete', { name: sticker.name });
  });
}

module.exports = { register };
