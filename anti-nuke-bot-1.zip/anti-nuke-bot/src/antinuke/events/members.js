const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');
const { consumeTrusted } = require('../trustedActions');

function register(client) {
  // Mass ban
  client.on('guildBanAdd', async (ban) => {
    const guild = ban.guild;
    // Ban phat ra tu lenh /ban cua chinh bot da duoc danh dau tin cay -> bo qua dem nguong,
    // tranh mod dang don raid bang /ban bi chinh anti-nuke tuoc quyen/ban oan.
    if (consumeTrusted(guild.id, ban.user.id, 'ban')) return;
    const result = await fetchLatestExecutor(guild, AuditLogEvent.MemberBanAdd, { targetId: ban.user.id });
    if (result) await handleAction(client, guild, result.executorId, 'massBan', { userId: ban.user.id });
  });

  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    const guild = newMember.guild;

    // Mass timeout
    const oldTimeout = oldMember.communicationDisabledUntilTimestamp;
    const newTimeout = newMember.communicationDisabledUntilTimestamp;
    if (newTimeout && newTimeout !== oldTimeout && newTimeout > Date.now()) {
      if (consumeTrusted(guild.id, newMember.id, 'timeout')) return;
      const result = await fetchLatestExecutor(guild, AuditLogEvent.MemberUpdate, { targetId: newMember.id });
      if (result) await handleAction(client, guild, result.executorId, 'massTimeout', { memberId: newMember.id });
    }

    // Mass role add / remove tren mot thanh vien
    const oldRoles = oldMember.roles.cache;
    const newRoles = newMember.roles.cache;
    const added = newRoles.filter((r) => !oldRoles.has(r.id));
    const removed = oldRoles.filter((r) => !newRoles.has(r.id));
    if (added.size || removed.size) {
      const result = await fetchLatestExecutor(guild, AuditLogEvent.MemberRoleUpdate, { targetId: newMember.id });
      if (result) {
        if (added.size) {
          await handleAction(client, guild, result.executorId, 'massRoleAdd', {
            memberId: newMember.id,
            addedRoleIds: added.map((r) => r.id),
          });
        }
        if (removed.size) {
          await handleAction(client, guild, result.executorId, 'massRoleRemove', {
            memberId: newMember.id,
            removedRoleIds: removed.map((r) => r.id),
          });
        }
      }
    }
  });

  // Mass bot invite
  client.on('guildMemberAdd', async (member) => {
    if (!member.user.bot) return;
    const result = await fetchLatestExecutor(member.guild, AuditLogEvent.BotAdd, { targetId: member.id });
    if (result) await handleAction(client, member.guild, result.executorId, 'massBotAdd', { botId: member.id });
  });
}

module.exports = { register };
