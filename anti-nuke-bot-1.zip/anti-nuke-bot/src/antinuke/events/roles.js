const { AuditLogEvent } = require('discord.js');
const { fetchLatestExecutor } = require('../auditLog');
const { handleAction } = require('../engine');

function snapshotRole(role) {
  return {
    name: role.name,
    color: role.color,
    hoist: role.hoist,
    mentionable: role.mentionable,
    permissions: role.permissions.bitfield.toString(),
  };
}

function register(client) {
  client.on('roleCreate', async (role) => {
    const result = await fetchLatestExecutor(role.guild, AuditLogEvent.RoleCreate, { targetId: role.id });
    if (result) await handleAction(client, role.guild, result.executorId, 'massRoleCreate', { roleId: role.id });
  });

  client.on('roleDelete', async (role) => {
    const result = await fetchLatestExecutor(role.guild, AuditLogEvent.RoleDelete, { targetId: role.id });
    if (result) await handleAction(client, role.guild, result.executorId, 'massRoleDelete', snapshotRole(role));
  });

  client.on('roleUpdate', async (oldRole, newRole) => {
    const permsChanged = oldRole.permissions.bitfield !== newRole.permissions.bitfield;
    const otherChanged =
      oldRole.name !== newRole.name ||
      oldRole.color !== newRole.color ||
      oldRole.hoist !== newRole.hoist ||
      oldRole.mentionable !== newRole.mentionable ||
      oldRole.position !== newRole.position;
    if (!permsChanged && !otherChanged) return;

    const moduleKey = permsChanged ? 'massPermissionChange' : 'massRoleUpdate';
    const result = await fetchLatestExecutor(newRole.guild, AuditLogEvent.RoleUpdate, { targetId: newRole.id });
    if (result) await handleAction(client, newRole.guild, result.executorId, moduleKey, { roleId: newRole.id });
  });
}

module.exports = { register, snapshotRole };
