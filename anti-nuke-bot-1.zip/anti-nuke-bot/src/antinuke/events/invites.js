const { handleAction } = require('../engine');

function register(client) {
  client.on('inviteCreate', async (invite) => {
    if (!invite.guild || !invite.inviter) return;
    await handleAction(client, invite.guild, invite.inviter.id, 'massInviteCreate', { code: invite.code });
  });
}

module.exports = { register };
