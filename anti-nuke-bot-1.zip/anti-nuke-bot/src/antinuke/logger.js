// Gui embed canh bao vao kenh log da cau hinh.
const { EmbedBuilder } = require('discord.js');

async function sendAlert(guild, config, { title, description, color = 0xed4245, fields = [] }) {
  if (!config.logChannelId) return;
  const channel = guild.channels.cache.get(config.logChannelId);
  if (!channel || !channel.isTextBased()) return;
  const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setTimestamp();
  if (fields.length) embed.addFields(fields);
  channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { sendAlert };
