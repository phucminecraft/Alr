// File khoi dong bot vi du - ghep module Anti-Nuke vao mot Discord client that.
require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { setupAntiNuke } = require('./antinuke');
const { setupModeration } = require('./moderation');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // can bat "Server Members Intent" trong Developer Portal
    GatewayIntentBits.GuildModeration, // ban/unban
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildIntegrations,
  ],
  partials: [Partials.GuildMember],
});

setupAntiNuke(client);
setupModeration(client);

client.once('ready', () => {
  console.log(`Da dang nhap voi ten ${client.user.tag}. Anti-Nuke dang hoat dong.`);
});

client.login(process.env.DISCORD_TOKEN);
