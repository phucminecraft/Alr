// Lap rap toan bo lenh moderation vao client co san.
const { commands } = require('./commands');

const byName = new Map(commands.map((c) => [c.data.name, c]));

function setupModeration(client) {
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    const cmd = byName.get(interaction.commandName);
    if (!cmd) return;
    try {
      await cmd.execute(interaction);
    } catch (err) {
      console.error(err);
      const payload = { content: 'Da xay ra loi khi xu ly lenh.', ephemeral: true };
      if (interaction.deferred || interaction.replied) interaction.editReply(payload).catch(() => {});
      else interaction.reply(payload).catch(() => {});
    }
  });
}

module.exports = { setupModeration, commands };
