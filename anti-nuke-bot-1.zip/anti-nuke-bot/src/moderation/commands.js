// Toan bo lenh moderation: /ban /kick /mute /unmute /timeout /unban.
// Gop chung 1 file (thay vi tach moi lenh 1 file) de giu cau truc du an gon
// nhu ban goc gui, dong thoi chia se cac ham dung chung (checkHierarchy, muted role).
//
// Toc do: khong co buoc tra audit log nao trong duong di cua lenh (khac voi
// antinuke, noi bat buoc phai tra audit log de biet ai la thu pham). O day
// nguoi thuc hien da chinh la interaction.user, nen goi thang API roi reply
// ngay - khong co delay nhan tao nao duoc chen vao.
//
// Phan quyen: dat qua setDefaultMemberPermissions() cho tung lenh -> Discord tu
// an lenh khoi nguoi khong co quyen (khong ai thay lenh de bam nham, khong ton
// round-trip nao ve phia bot). Cong them 1 lop kiem tra lai trong code (re-check
// quyen + thu bac role) phong truong hop admin server tuy chinh lai quyen mac dinh
// cua lenh trong Integrations settings.
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
} = require('discord.js');
const { markTrusted } = require('../antinuke/trustedActions');

const MAX_TIMEOUT_MINUTES = 40_320; // 28 ngay, gioi han cung cua Discord

function errorEmbed(desc) {
  return new EmbedBuilder().setColor(0xed4245).setDescription(`❌ ${desc}`);
}

function okEmbed(desc) {
  return new EmbedBuilder().setColor(0x57f287).setDescription(`✅ ${desc}`);
}

// Kiem tra thu bac role: khong the tac dong len nguoi co role cao hon hoac
// bang role cao nhat cua nguoi ra lenh (tru chu server), va bot phai co role
// cao hon target thi API moi cho phep thao tac.
function checkHierarchy(interaction, targetMember) {
  const guild = interaction.guild;
  if (targetMember.id === guild.ownerId) return 'Khong the thao tac len chu server.';
  if (targetMember.id === interaction.user.id) return 'Khong the tu thao tac len chinh minh.';
  if (targetMember.id === interaction.client.user.id) return 'Khong the thao tac len chinh bot.';

  const botMember = guild.members.me;
  if (botMember.roles.highest.position <= targetMember.roles.highest.position && guild.ownerId !== botMember.id) {
    return 'Bot khong du thu bac (role muc tieu >= role cao nhat cua bot).';
  }

  const executorMember = interaction.member;
  if (
    guild.ownerId !== executorMember.id &&
    executorMember.roles.highest.position <= targetMember.roles.highest.position
  ) {
    return 'Ban khong the thao tac len nguoi co role cao hon hoac bang ban.';
  }
  return null;
}

async function getOrCreateMutedRole(guild) {
  let role = guild.roles.cache.find((r) => r.name === 'Muted');
  if (role) return role;

  role = await guild.roles.create({
    name: 'Muted',
    color: 0x5c5c5c,
    permissions: [],
    reason: 'Tu dong tao role Muted cho lenh /mute',
  });

  // Ap overwrite tren tat ca channel hien co - chi chay 1 lan duy nhat luc tao role,
  // cac lan /mute sau chi la gan role, khong dung lai buoc nay nen khong anh huong toc do.
  const denyPerms = [
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.SendMessagesInThreads,
    PermissionFlagsBits.AddReactions,
    PermissionFlagsBits.Speak,
    PermissionFlagsBits.Stream,
    PermissionFlagsBits.CreatePublicThreads,
    PermissionFlagsBits.CreatePrivateThreads,
  ];
  await Promise.allSettled(
    guild.channels.cache
      .filter((c) => c.type !== ChannelType.GuildCategory)
      .map((c) => c.permissionOverwrites.create(role, Object.fromEntries(denyPerms.map((p) => [permKeyName(p), false]))).catch(() => {}))
  );
  return role;
}

// PermissionFlagsBits la BigInt, discord.js can ten key dang string cho overwrite object.
const FLAG_NAME_MAP = new Map(Object.entries(PermissionFlagsBits).map(([name, val]) => [val, name]));
function permKeyName(flag) {
  return FLAG_NAME_MAP.get(flag);
}

const commands = [
  {
    data: new SlashCommandBuilder()
      .setName('ban')
      .setDescription('Cam vinh vien mot thanh vien khoi server')
      .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can ban').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Ly do'))
      .addIntegerOption((o) =>
        o.setName('delete_days').setDescription('Xoa tin nhan cua ho trong bao nhieu ngay gan day (0-7)').setMinValue(0).setMaxValue(7)
      ),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.BanMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Ban Members.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Khong co ly do';
      const deleteDays = interaction.options.getInteger('delete_days') ?? 0;

      const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (targetMember) {
        const hierarchyError = checkHierarchy(interaction, targetMember);
        if (hierarchyError) return interaction.reply({ embeds: [errorEmbed(hierarchyError)], ephemeral: true });
      }

      try {
        // Danh dau truoc khi goi API: event guildBanAdd co the ban ra gan nhu ngay lap tuc.
        markTrusted(interaction.guild.id, user.id, 'ban');
        await interaction.guild.members.ban(user.id, { deleteMessageSeconds: deleteDays * 86_400, reason: `${reason} (mod: ${interaction.user.tag})` });
        return interaction.reply({ embeds: [okEmbed(`Da ban **${user.tag}**. Ly do: ${reason}`)] });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(`Khong the ban: ${err.message}`)], ephemeral: true });
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('unban')
      .setDescription('Go ban cho mot nguoi dung theo ID')
      .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
      .addStringOption((o) => o.setName('user_id').setDescription('ID nguoi dung can go ban').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Ly do')),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.BanMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Ban Members.')], ephemeral: true });
      }
      const userId = interaction.options.getString('user_id', true);
      const reason = interaction.options.getString('reason') || 'Khong co ly do';
      try {
        await interaction.guild.members.unban(userId, `${reason} (mod: ${interaction.user.tag})`);
        return interaction.reply({ embeds: [okEmbed(`Da go ban cho \`${userId}\`.`)] });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(`Khong the go ban: ${err.message}`)], ephemeral: true });
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('kick')
      .setDescription('Duoi mot thanh vien khoi server')
      .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can kick').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Ly do')),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.KickMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Kick Members.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Khong co ly do';
      const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!targetMember) return interaction.reply({ embeds: [errorEmbed('Nguoi nay khong con trong server.')], ephemeral: true });

      const hierarchyError = checkHierarchy(interaction, targetMember);
      if (hierarchyError) return interaction.reply({ embeds: [errorEmbed(hierarchyError)], ephemeral: true });

      try {
        await targetMember.kick(`${reason} (mod: ${interaction.user.tag})`);
        return interaction.reply({ embeds: [okEmbed(`Da kick **${user.tag}**. Ly do: ${reason}`)] });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(`Khong the kick: ${err.message}`)], ephemeral: true });
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('timeout')
      .setDescription('Cam noi (Discord timeout) mot thanh vien trong khoang thoi gian')
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can timeout').setRequired(true))
      .addIntegerOption((o) => o.setName('minutes').setDescription('So phut (toi da 40320 = 28 ngay)').setRequired(true).setMinValue(1).setMaxValue(MAX_TIMEOUT_MINUTES))
      .addStringOption((o) => o.setName('reason').setDescription('Ly do')),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ModerateMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Timeout Members.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const minutes = interaction.options.getInteger('minutes', true);
      const reason = interaction.options.getString('reason') || 'Khong co ly do';
      const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!targetMember) return interaction.reply({ embeds: [errorEmbed('Nguoi nay khong con trong server.')], ephemeral: true });

      const hierarchyError = checkHierarchy(interaction, targetMember);
      if (hierarchyError) return interaction.reply({ embeds: [errorEmbed(hierarchyError)], ephemeral: true });

      try {
        markTrusted(interaction.guild.id, targetMember.id, 'timeout');
        await targetMember.timeout(minutes * 60_000, `${reason} (mod: ${interaction.user.tag})`);
        return interaction.reply({ embeds: [okEmbed(`Da timeout **${user.tag}** trong ${minutes} phut. Ly do: ${reason}`)] });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(`Khong the timeout: ${err.message}`)], ephemeral: true });
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('mute')
      .setDescription('Cam noi vinh vien bang role Muted (khac timeout - khong tu het han)')
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can mute').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Ly do')),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ModerateMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Moderate Members.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Khong co ly do';
      const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!targetMember) return interaction.reply({ embeds: [errorEmbed('Nguoi nay khong con trong server.')], ephemeral: true });

      const hierarchyError = checkHierarchy(interaction, targetMember);
      if (hierarchyError) return interaction.reply({ embeds: [errorEmbed(hierarchyError)], ephemeral: true });

      // Lan dau tien tao role Muted phai tao overwrite tren toan bo channel -> co the mat vai giay,
      // deferReply de tranh loi "Unknown interaction" do qua 3s.
      const mutedRoleExists = interaction.guild.roles.cache.some((r) => r.name === 'Muted');
      if (!mutedRoleExists) await interaction.deferReply();

      try {
        const role = await getOrCreateMutedRole(interaction.guild);
        await targetMember.roles.add(role, `${reason} (mod: ${interaction.user.tag})`);
        const embed = okEmbed(`Da mute **${user.tag}**. Ly do: ${reason}`);
        return interaction.deferred ? interaction.editReply({ embeds: [embed] }) : interaction.reply({ embeds: [embed] });
      } catch (err) {
        const embed = errorEmbed(`Khong the mute: ${err.message}`);
        return interaction.deferred ? interaction.editReply({ embeds: [embed] }) : interaction.reply({ embeds: [embed], ephemeral: true });
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('unmute')
      .setDescription('Go role Muted khoi mot thanh vien')
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can unmute').setRequired(true)),
    async execute(interaction) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ModerateMembers)) {
        return interaction.reply({ embeds: [errorEmbed('Ban khong co quyen Moderate Members.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      const role = interaction.guild.roles.cache.find((r) => r.name === 'Muted');
      if (!targetMember || !role || !targetMember.roles.cache.has(role.id)) {
        return interaction.reply({ embeds: [errorEmbed('Nguoi nay hien khong bi mute.')], ephemeral: true });
      }
      try {
        await targetMember.roles.remove(role, `Unmute (mod: ${interaction.user.tag})`);
        return interaction.reply({ embeds: [okEmbed(`Da unmute **${user.tag}**.`)] });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(`Khong the unmute: ${err.message}`)], ephemeral: true });
      }
    },
  },
];

module.exports = { commands };
