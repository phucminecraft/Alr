// Chay: npm run deploy  ->  dang ky /antinuke va toan bo lenh moderation.
require('dotenv').config();
const { REST, Routes } = require('discord.js');
const antinuke = require('./antinuke/commands/antinuke');
const { commands: modCommands } = require('./moderation/commands');

const commands = [antinuke.data.toJSON(), ...modCommands.map((c) => c.data.toJSON())];
const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    const route = process.env.GUILD_ID
      ? Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID)
      : Routes.applicationCommands(process.env.CLIENT_ID);
    await rest.put(route, { body: commands });
    console.log(`Da dang ky ${commands.length} slash command: ${commands.map((c) => c.name).join(', ')}.`);
  } catch (err) {
    console.error(err);
  }
})();
