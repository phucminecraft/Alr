# Anti-Nuke Bot (discord.js v14)

Module bảo vệ server chống mass-nuke: phát hiện một tài khoản thực hiện quá nhiều hành động phá hoại trong một khoảng thời gian ngắn, tự động cách ly/ban/kick kẻ đó, và cố gắng khôi phục thiệt hại.

## 25 module được giám sát

Mass Bans, Mass Timeouts, Mass Role Adds, Mass Role Removes, Mass Channel Creation/Deletion/Updates, Mass Category Creation/Deletion, Mass Thread Creation/Deletion, Mass Role Creation/Deletion/Updates, Mass Permission Changes, Mass Webhook Creation/Deletion, Mass Emoji Creation/Deletion, Mass Sticker Creation/Deletion, Mass Invite Creation, Mass Integration Changes, Mass Bot Invites, Server Setting Changes.

Mỗi module có 3 tham số chỉnh được: **limit** (số hành động), **thời gian** (giây/phút/giờ), **hình phạt** (ban, kick, timeout 28 ngày, hoặc strip — chỉ gỡ role nguy hiểm).

## Cài đặt

```bash
npm install
cp .env.example .env
```

Điền vào `.env`:
- `DISCORD_TOKEN` — token bot, lấy tại Discord Developer Portal.
- `CLIENT_ID` — application ID của bot.
- `GUILD_ID` — để trống nếu muốn deploy global; điền ID server để test nhanh (slash command cập nhật tức thì).

Trong Developer Portal, mục **Bot**, bật **Server Members Intent**. Đây là intent có giới hạn (privileged), thiếu nó thì các event ban/timeout/role/bot-invite sẽ không chạy.

Mời bot vào server với các quyền: Administrator (khuyến nghị), hoặc tối thiểu Ban Members, Kick Members, Moderate Members, Manage Roles, Manage Channels, Manage Webhooks, Manage Guild, Manage Emojis and Stickers, Manage Threads, View Audit Log. **Role của bot phải nằm trên các role mà bạn muốn nó có thể gỡ hoặc cấm** — nếu không, cơ chế cách ly (strip role) và các lệnh `/ban /kick /mute /timeout` sẽ không thực hiện được với những role/thành viên nằm cao hơn bot.

Đăng ký slash command rồi chạy bot:

```bash
npm run deploy
npm start
```

## Sử dụng lệnh `/antinuke`

- `/antinuke setup channel:#log` — đặt kênh nhận cảnh báo.
- `/antinuke config module:<...> limit:<số> amount:<số> unit:<giây|phút|giờ> punishment:<...>` — chỉnh ngưỡng riêng cho từng module.
- `/antinuke toggle module:<...> state:<true|false>` — bật/tắt một module.
- `/antinuke whitelist add-user|remove-user|add-role|remove-role|add-bot|remove-bot` — quản lý danh sách miễn trừ.
- `/antinuke status` — xem toàn bộ cấu hình hiện tại.
- `/antinuke backup now|status|interval` — quản lý snapshot dùng để khôi phục toàn diện (xem bên dưới).
- `/antinuke restore confirm:true` — khôi phục toàn bộ role/channel từ snapshot gần nhất.

Chủ server luôn được miễn trừ mặc định, và bot tự bỏ qua chính hành động của nó.

## Cơ chế phản ứng

Khi một tài khoản vượt ngưỡng, bot thực hiện theo thứ tự:
1. Gỡ ngay các role có quyền nguy hiểm (Administrator, Ban Members, Manage Roles, Manage Channels...) mà bot còn đủ thứ bậc để thao tác.
2. Áp dụng hình phạt đã cấu hình cho module đó (ban / kick / timeout / chỉ dừng ở bước 1).
3. Gửi embed cảnh báo vào kênh log.
4. Cố gắng khôi phục: gỡ ban cho nạn nhân bị mass-ban, tạo lại kênh/category/role vừa bị xóa hàng loạt (tên, quyền, permission overwrite), hoàn trả role bị tước hoặc gỡ role bị cấp trái phép hàng loạt.
5. **Với các module phá hoại diện rộng** (mass xóa channel/category/role), bot chạy thêm một lượt **khôi phục toàn diện** (`restoreAll`, xem mục dưới) để vét nốt những gì nằm ngoài phạm vi bước 4 — ví dụ kẻ tấn công dùng nhiều tài khoản/webhook khác nhau, hoặc xóa vài cái trước khi vượt ngưỡng.

Việc khôi phục là best-effort. Vị trí chính xác trong danh sách kênh/role và lịch sử tin nhắn trong kênh bị xóa sẽ không phục hồi lại được — Discord không giữ lại các dữ liệu đó sau khi xóa.

## Khôi phục toàn diện (backup / restore)

Ngoài cơ chế restore theo từng hành động ở trên, bot còn giữ **snapshot toàn bộ cấu trúc server** (tên, quyền, permission overwrite của mọi role và channel/category) tại `data/guilds/<guildId>.snapshot.json`:

- Snapshot đầu tiên được chụp ngay khi bot khởi động, sau đó tự động chụp lại định kỳ (mặc định 15 phút, chỉnh bằng `/antinuke backup interval`).
- `/antinuke backup now` — chụp thủ công ngay lập tức (nên làm sau khi setup server xong).
- `/antinuke restore confirm:true` — đối chiếu snapshot gần nhất với trạng thái hiện tại, tạo lại **mọi** role/channel có trong snapshot nhưng đang thiếu (khớp theo tên, không tạo trùng nếu tên đã tồn tại).

Giới hạn của restore toàn diện: Discord không giữ lại ID cũ, nên role/channel được tạo lại sẽ có ID mới (mọi nhắc `@role` hay link cũ trong tin nhắn sẽ không tự cập nhật); vị trí chính xác trong danh sách và permission overwrite theo từng thành viên riêng lẻ (không phải theo role) không được lưu lại. Đây là lưới an toàn cuối, không thay thế cho backup thủ công bên ngoài nếu server có cấu trúc phức tạp.

## Lệnh moderation (`/ban /kick /mute /unmute /timeout /unban`)

Các lệnh này độc lập với hệ thống anti-nuke nhưng dùng chung project để tiện quản lý:

- Mỗi lệnh yêu cầu đúng quyền Discord gốc tương ứng (`Ban Members`, `Kick Members`, `Moderate Members`) qua `setDefaultMemberPermissions` — Discord tự ẩn lệnh khỏi người không đủ quyền, không cần bước kiểm tra nào tốn thời gian phía bot. Ngoài ra bot vẫn re-check quyền và **thứ bậc role** (không thể ban/kick/timeout người có role cao hơn hoặc bằng mình, không thể động vào chủ server) để tránh lạm dụng nếu admin chỉnh lại quyền mặc định của lệnh.
- Không có bước tra audit log nào trong lệnh (khác với anti-nuke) — người thực hiện chính là người gõ lệnh, nên gọi thẳng API rồi phản hồi ngay, không có độ trễ nhân tạo.
- `/mute` dùng role "Muted" tự tạo (deny gửi tin/nói ở mọi kênh) — khác `/timeout` (giới hạn 28 ngày của Discord) ở chỗ mute không tự hết hạn, phải `/unmute` thủ công.
- **Tương thích với anti-nuke**: khi mod dùng `/ban` hoặc `/timeout`, hành động đó được đánh dấu "tin cậy" trong vài giây để anti-nuke không đếm nhầm vào ngưỡng Mass Ban / Mass Timeout — tránh trường hợp mod đang dọn raid (ban dồn dập) bị chính bot tự động tước quyền/ban oan.

Cần chạy lại `npm run deploy` sau khi cập nhật để Discord nhận các slash command mới.

## Giới hạn cần biết

Audit log của Discord đôi khi mất 1-2 giây để xuất hiện; bot đã chờ trước khi tra cứu nhưng trong trường hợp mạng chậm bất thường, một hành động riêng lẻ có thể bị bỏ sót khỏi bộ đếm. Nếu kẻ tấn công có role ngang hàng hoặc cao hơn role của bot, bot sẽ không thể gỡ role hay ban được — thứ bậc role trong server quyết định giới hạn thực tế của bất kỳ anti-nuke bot nào, không riêng bot này.

Cấu hình mỗi server được lưu tại `data/guilds/<guildId>.json`, snapshot khôi phục toàn diện tại `data/guilds/<guildId>.snapshot.json`.
